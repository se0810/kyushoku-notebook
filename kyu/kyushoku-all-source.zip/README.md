# きゅうしょく手帖 — 60レシピ版

公式出典付き12件（草加市6件・ふじみ野市6件）と創作サンプル48件、合計60件。今回の更新はローカル完成版です。既存の公開URLへの反映は、Sites同期のネットワーク権限が拒否されたため未完了です。

## 開き方

ZIP内の kyushoku-60.html をブラウザで開くと、サーバー不要で試せます。サイトの編集用ソースは dist/ にあります。

## 追加した機能

全60レシピへのショートカット、地方・市町村フィルター、お気に入り保存と絞り込み、料理名/都道府県順の並べ替え、条件内から一皿をランダムに選択、関連レシピ、レシピの印刷。お気に入りは同じブラウザに保存され、端末間同期はありません。保存領域が使えない環境では画面内だけ保持します。

## データの意味

公式レシピの材料は原典の分量を採用し、作り方は独自の文章で要約。補足は明記。dataKind: verified はレシピの出典確認を意味し、提供記録の確認を意味しません。source.scope: recipe として確認範囲を保持します。提供日・提供年代は不明（null）で、特定年代検索には含めません。原典更新年やURLの年を提供年へ転用していません。

創作サンプルの地域・年代・レシピはデモ設定です。新規創作36件は場所・年代を未設定にしています。47都道府県を選べますが、全県の実資料を収録した状態ではありません。

## データ構造

固定ID、都道府県コード、市町村、分類、提供日/年、出典種別を分離。source に URL/発行者/タイトル/確認日/確認範囲、recipe に人数または個数・材料・手順・調理メモ・出典を保持。提供実績を追加するときは recipes と menuOccurrences を分け、後者が schoolId / recipeId / servedDate / sourceId を参照する構造へ拡張できます。分類は本サイトの整理用区分です。

## 検証

JavaScript構文、60件のID一意性、公式12件の出典と提供年null、地方の47県網羅、県・市・年代・検索・お気に入り条件を検証。ブラウザでの実機表示・操作・印刷確認は未完了です。

## 公式出典（確認日：2026-10-17）

- 草加市：[わかめごはん](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079885.html)
- 草加市：[とうふめし](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079884.html)
- 草加市：[冷や汁うどん](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079891.html)
- 草加市：[さつまいも蒸しパン](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079897.html)
- 草加市：[磯香和え](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079903.html)
- 草加市：[じゃが丸くん](https://www.city.soka.saitama.jp/cont/s2102/PAGE000000000000079918.html)
- ふじみ野市：[豚肉の生姜焼き](https://www.city.fujimino.saitama.jp/material/files/group/39/shougayaki.pdf)
- ふじみ野市：[ミートソース](https://www.city.fujimino.saitama.jp/material/files/group/39/meatsause.pdf)
- ふじみ野市：[切り干し大根のごま塩サラダ](https://www.city.fujimino.saitama.jp/material/files/group/39/202602kiriboshigomashiosarada.pdf)
- ふじみ野市：[きなこ揚げパン](https://www.city.fujimino.saitama.jp/material/files/group/39/agepan.pdf)
- ふじみ野市：[ABCスープ](https://www.city.fujimino.saitama.jp/material/files/group/39/ABCsupu202410.pdf)
- ふじみ野市：[さばのごまだれかけ](https://www.city.fujimino.saitama.jp/material/files/group/39/sabanogomadarekake202409.pdf)

